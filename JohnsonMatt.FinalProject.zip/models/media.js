
const video = {
    id:'video',
    src: 'http://apollo.gtc.edu/~hurc/152-182/video/lighthouse.m4v'
}

const audio = {
    id:'audio',
    src: 'http://apollo.gtc.edu/~hurc/152-182/podcast/podcast.mp3'
}

module.exports = {video, audio}