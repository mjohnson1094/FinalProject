const books = [
    {'id':1,
     'title':'Intro to HTML5',
     'author':'Chrsitian Hur',
     'publisher':'Hur Publication',
     'year':2020},
    {'id':2,
     'title':'The MEAN Stack',
     'author':'Lois Lane','publisher':'Daily Planet',
     'year':2019},
    {'id':3,
     'title':'AJAX Made Simple',
     'author':'Alvin',
     'publisher':'Chipmunks Publication',
     'year':2021}
]
 
module.exports.books = books;
