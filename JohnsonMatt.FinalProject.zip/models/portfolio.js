const projects = [
    {
        title:'Personal Site',
        description: 'My personal web site using Node.js/Express.js',
        url:'http://apollo.gtc.edu/~mjohnson/webprog2/unit1/index.html'
    },
    {
        title:'The GuestBook Page',
        description: 'My guestbook web site allowing users to register and sign the guestbook',
        url:'http://apollo.gtc.edu/~mjohnson/advphp/unit2/index.php'
    },
    {
        title:'Vehicle Webpage',
        description: '',
        url:'http://apollo.gtc.edu/~mjohnson/advphp/unit3/vehicle.php'
    },
]

exports.projects = projects